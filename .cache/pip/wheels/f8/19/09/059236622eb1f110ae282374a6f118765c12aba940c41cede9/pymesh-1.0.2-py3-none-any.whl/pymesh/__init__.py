# -*- coding: utf-8 -*-

#
# PyMesh
#

__title__ = "pymesh"
__versioninfo__ = (1, 0, 2)
__version__ = ".".join(map(str, __versioninfo__))
__author__ = "Takuro Wada"
__license__ = "MIT"
__copyright__ = "Copyright 2015 Takuro Wada"
__url__ = "https://github.com/taxpon/pymesh"
